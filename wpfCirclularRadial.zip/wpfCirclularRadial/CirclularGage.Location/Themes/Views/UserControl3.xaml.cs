﻿using System.Windows.Controls;

namespace CirclularGage.Themes.Views
{
    /// <summary>
    /// UserControl3.xaml에 대한 상호 작용 논리
    /// </summary>
    public partial class UserControl3 : UserControl
    {
        public UserControl3()
        {
            InitializeComponent();
        }
    }
}
