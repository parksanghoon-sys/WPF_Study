﻿namespace CirclularGage.Location.Local.Enums
{
    public enum IntruderVerticalSenseState
    {
        NoVerticalRate,
        Climbing,
        Descending,
        NoData
    }
}
