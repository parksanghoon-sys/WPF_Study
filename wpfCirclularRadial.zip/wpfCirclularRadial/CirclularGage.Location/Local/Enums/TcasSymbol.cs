﻿namespace CirclularGage.Location.Local.Enums
{
    public enum TcasSymbol
    {
        OtherTraffic,
        ProximateTraffic,
        TrafficAdvisory,
        ResolutionAdvisorty,
        Nodata
    }
}
