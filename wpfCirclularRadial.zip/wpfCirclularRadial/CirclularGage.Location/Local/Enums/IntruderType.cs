﻿namespace CirclularGage.Location.Local.Enums
{
    public enum DisplayMatrix
    {
        NoThreat,
        TA,
        RA,
        ProximateTime,        
    }
}
